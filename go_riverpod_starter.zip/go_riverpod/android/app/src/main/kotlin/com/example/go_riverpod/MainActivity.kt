package com.example.go_riverpod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
